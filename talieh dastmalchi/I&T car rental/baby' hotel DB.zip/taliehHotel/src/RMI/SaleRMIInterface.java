/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package RMI;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;

import Common.ReserveENT;
import Common.RoomENT;
import Common.UserENT;

/**
 *
 * @author Talieh Dastmalchi
 */
public interface SaleRMIInterface extends Remote {
    public String helloRMI (String name) throws RemoteException;
    public ArrayList<UserENT> allUsers() throws RemoteException;
    public UserENT login(String u, String p) throws RemoteException;
    public void insertBook(ReserveENT ent) throws RemoteException;
    public void insertRoom(RoomENT rent) throws RemoteException;
    public boolean register(UserENT UserENT) throws RemoteException;
    public RoomENT searchForRoom(ReserveENT reserveENT) throws RemoteException;
    public void activation(boolean p, String uname) throws RemoteException;
    
    
}
