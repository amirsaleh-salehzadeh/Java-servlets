/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package RMI;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

import Business.bsManager;
import Common.ReserveENT;
import Common.RoomENT;
import Common.UserENT;

/**
 *
 * @author Talieh Dastmalchi
 */
public class SaleRMIServer extends UnicastRemoteObject implements SaleRMIInterface {
    public static void main(String[] args){
        try{
            SaleRMIServer obj = new SaleRMIServer();
        }catch (RemoteException ex) {
                ex.printStackTrace();
        }
                
            }
       
   
    public SaleRMIServer() throws RemoteException{
        try{
            Naming.rebind("SaleRMIServer", this);
        }catch (MalformedURLException ex){
            //Logger.getLogger(SaleRMIServer.class.getName()).log(Level.SEVERE, null, ex);
            //server - mine
            ex.printStackTrace();
            //client -
            throw new RemoteException(ex.getMessage());
        }
        
    }
public String helloRMI(String name) throws RemoteException {
    //throw new UnsupportedOperationException("Not support yet.");
    return name+" Welcome to RMI";
}


public void activation(boolean p, String uname) throws RemoteException {
	bsManager bsManager = new bsManager();
	bsManager.activation(p, uname);
}


public ArrayList<UserENT> allUsers() throws RemoteException {
	bsManager bsManager = new bsManager();
	
	return bsManager.allUsers();
}


public void insertBook(ReserveENT ent) throws RemoteException {
	bsManager bsManager = new bsManager();
	bsManager.insertBook(ent);
	
}


public void insertRoom(RoomENT rent) throws RemoteException {
	bsManager bsManager = new bsManager();
	bsManager.insertRoom(rent);
	
}


public UserENT login(String u, String p) throws RemoteException {
	bsManager bsManager = new bsManager();
	
	return bsManager.login(u, p);
}


public boolean register(UserENT UserENT) throws RemoteException {
	bsManager bsManager = new bsManager();
	
	return bsManager.register(UserENT);
}


public RoomENT searchForRoom(ReserveENT reserveENT) throws RemoteException {
	bsManager bsManager = new bsManager();
	return bsManager.searchForRoom(reserveENT);
}


}
