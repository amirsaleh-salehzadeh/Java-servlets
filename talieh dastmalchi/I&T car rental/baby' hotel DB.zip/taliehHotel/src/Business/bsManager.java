/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Business;

import Common.*;

import java.sql.*;
import java.util.ArrayList;
/**
 *
 * @author Talieh Dastmalchi
 */
public class bsManager {

    public ArrayList<UserENT> allUsers() {
        ArrayList<UserENT> al = new ArrayList<UserENT>();
        try{
        Class.forName("com.mysql.jdbc.Driver");
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/taliehhotel", "root", "root");
        String sql="Select * from user";
        Statement stmt=con.createStatement();
        ResultSet rs = stmt.executeQuery(sql);
        
        while(rs.next())
        {
            UserENT user = new UserENT();
            user.setActive(rs.getBoolean("confirmed"));
            user.setUserName(rs.getString("username"));
            user.setName(rs.getString("name"));
            user.setFName(rs.getString("familyName"));
            al.add(user);
        }
       
        rs.close();
        stmt.close();
        con.close();
        }
        catch (Exception EX){
            EX.printStackTrace();
        }
        return al;
    }

    public UserENT login(String u, String p) {
    	UserENT user = new UserENT();
        try{
        Class.forName("com.mysql.jdbc.Driver");
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/taliehhotel", "root", "root");
        String sql="Select * from user where username = ? AND password = ? ";
        PreparedStatement ps=con.prepareStatement(sql);
        ps.setString(1,u);
        ps.setString(2,p);
        ResultSet rs = ps.executeQuery();
        
        if(rs.next()){
            user.setActive(rs.getBoolean("confirmed"));
            user.setUserName(rs.getString("username"));
            user.setName(rs.getString("name"));
            user.setFName(rs.getString("familyName"));
        }else{
            user=null;
        }
       
        rs.close();
        ps.close();
        con.close();
        }
        catch (Exception EX){
            user=null;
            EX.printStackTrace();
        }
    
    return user;
    }

    public void insertBook(ReserveENT ent) {
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/taliehhotel", "root", "root");
            String sql="Insert into booking (userName, fromDate, toDate, roomid) values (?,?,?,?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1,ent.getUserName());
            ps.setString(2,ent.getSDate());
            ps.setString(3,ent.getEDate());
            ps.setInt(4,ent.getRoomId());
            
            ps.execute();

            ps.close();
            con.close();
            
            }
            catch (Exception EX){
                EX.printStackTrace();
                
            }
    }

    public void insertRoom(RoomENT rent) {
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/taliehhotel", "root", "root");
            String sql="Insert into room(beds, available, price) values (?,?,?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1,rent.getBeds());
            ps.setInt(2,rent.getNumRooms());
            ps.setInt(3,rent.getPrice());
            ps.execute();

            ps.close();
            con.close();
            
            }
            catch (Exception EX){
                EX.printStackTrace();
                }
    }

    public boolean register(UserENT UserENT) {
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/taliehhotel", "root", "root");
            String sql="Insert into user (name, familyName, address, email, password, phone, username, confirmed) values (?,?,?,?,?,?,?,?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1,UserENT.getName());
            ps.setString(2,UserENT.getFName());
            ps.setString(3,UserENT.getAddress());
            ps.setString(4,UserENT.getEmail());
            ps.setString(5,UserENT.getPassword());
            ps.setString(6,UserENT.getPhoneNo());
            ps.setString(7,UserENT.getUserName());
            ps.setBoolean(8,UserENT.isActive());
            ps.execute();

            ps.close();
            con.close();
            return true;
            }
            catch (Exception EX){
                EX.printStackTrace();
                return false;
            }
    }

    public RoomENT searchForRoom(ReserveENT reserveENT) { 
        RoomENT roomENT = new RoomENT();
        try{
        Class.forName("com.mysql.jdbc.Driver");
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/taliehhotel", "root", "root");
        String sql="Select * from room where beds like ?";
        PreparedStatement ps=con.prepareStatement(sql);
        ps.setInt(1, reserveENT.getNumOfBeds());
        ResultSet rs = ps.executeQuery();
        while(rs.next())
        {
            roomENT.setId(rs.getInt("id"));
            roomENT.setNumRooms(rs.getInt("available"));
            roomENT.setBeds(rs.getInt("beds"));
            roomENT.setPrice(rs.getInt("price"));
        }
        rs.close();
        ps.close();
        sql="Select * from booking where roomId = ? and toDate > ? and fromDate < ? ";
        ps=con.prepareStatement(sql);

        ps.setInt(1, roomENT.getId());
        ps.setString(2, reserveENT.getSDate());
        ps.setString(3, reserveENT.getEDate());
         
        rs = ps.executeQuery();
        int counter = 0;
        while(rs.next())
        {
        counter++;
        }
        roomENT.setNumRooms(roomENT.getNumRooms()-counter);
        rs.close();
        ps.close();
        con.close();
        }
        catch (Exception EX){
            EX.printStackTrace();
        }
        return roomENT;
    }

    public void activation(boolean x, String uname) {
        try{
        Class.forName("com.mysql.jdbc.Driver");
        Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/taliehhotel", "root", "root");
        String sql="UPDATE user SET confirmed = ? WHERE username = ? ";
        PreparedStatement ps=con.prepareStatement(sql);
        ps.setBoolean(1,x);
        ps.setString(2,uname);
        ps.execute();   

        ps.close();
        
        con.close();
        }
        catch (Exception EX){
           EX.printStackTrace();
        }
    }
    

}
