/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package Common;

/**
 *
 * @author Talieh Dastmalchi
 */
public class RoomENT {
private int beds;
private int numRooms;
private int id;
private int price;


    public int getBeds() {
        return beds;
    }

    public void setBeds(int beds) {
        this.beds = beds;
    }


    public int getNumRooms() {
        return numRooms;
    }

    public void setNumRooms(int numberOfRooms) {
        this.numRooms = numberOfRooms;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
        
       
}
